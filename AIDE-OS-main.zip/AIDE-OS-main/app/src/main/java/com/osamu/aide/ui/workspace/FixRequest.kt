package com.osamu.aide.ui.workspace

import com.osamu.aide.engine.api.Diagnostic
import java.io.File

/**
 * The message "fix this" sends on the user's behalf.
 *
 * Written here rather than in `:ai:core` because it is the one place that knows
 * both a [Diagnostic] and where the project root is, and `:ai:core` has no
 * business depending on the build engine's types.
 *
 * **The path is made relative on purpose.** The assistant's tools reject an
 * absolute path outright -- `ProjectFiles.resolve` refuses them so the model
 * learns to send relative ones -- so pasting `/storage/.../src/Main.java` into
 * the message would spend the first tool call on a refusal, and possibly the
 * second on the model guessing at the right form. Handing it the path its own
 * tools accept skips both.
 *
 * The source line is not included. The assistant has `read_file` and will use
 * it, and a line quoted here is a line that can already be stale by the time it
 * is read -- the user may have edited the file since the build ran.
 *
 * **That reasoning only holds if the file has been written.** A diagnostic from
 * the language service describes the buffer, and `read_file` reads the disk, so
 * an unsaved edit makes the two describe different programs -- the assistant
 * reads a file with no error in it and is asked what is causing one. The caller
 * saves first; `WorkspaceScreen.askToFix`.
 */
fun fixRequest(diagnostic: Diagnostic, projectRoot: File): String {
    val where = diagnostic.file?.relativeToProject(projectRoot)

    return buildString {
        // Not "the build reported": most of these come from the language
        // service as the user types, and a message that names the wrong source
        // invites the assistant to go looking in the wrong place -- which one
        // of them did, running a build to check and reporting that the build
        // said something else entirely.
        append("This ")
        append(diagnostic.severity.name.lowercase())
        append(" was reported:\n\n")

        if (where != null) {
            append(where)
            if (diagnostic.line != Diagnostic.UNKNOWN) {
                append(":").append(diagnostic.line)
                if (diagnostic.column != Diagnostic.UNKNOWN) append(":").append(diagnostic.column)
            }
            append("\n")
        }
        append(diagnostic.message.trim())

        // Asking for the cause rather than only the edit, because a build error
        // is usually a symptom -- a missing import for a type that was renamed,
        // say -- and an edit that silences it without saying why leaves the user
        // unable to tell a fix from a workaround.
        append("\n\nRead the file, tell me what is causing it, and fix it.")
    }
}

/**
 * The path as the assistant's tools expect it, or the plain name if the file is
 * somehow outside the project -- which is better than an absolute path the
 * tools will refuse.
 *
 * **Already relative is the usual case, not the odd one.** Every diagnostic
 * producer relativises through `ProjectPaths`, and `relativeTo` throws on a
 * relative path against an absolute root -- so the fallback turned every real
 * diagnostic into a bare name: `Main.java:12`, which `read_file` cannot find,
 * and `strings.xml` with no way to tell `values` from `values-night`. Only the
 * tests, which built diagnostics with absolute paths, ever reached the
 * `relativeTo`.
 */
internal fun File.relativeToProject(root: File): String {
    if (!isAbsolute) return path
    val relative = runCatching { relativeTo(root).path }.getOrNull()
    return if (relative.isNullOrBlank() || relative.startsWith("..")) name else relative
}
